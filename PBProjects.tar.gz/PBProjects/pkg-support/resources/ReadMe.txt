This is an example portable sound library for use with SDL.

The source code is available from:
http://www.icculus.org/SDL_sound/

This library is distributed under the terms of the GNU LGPL license: http://www.gnu.org/copyleft/lesser.html
